# advancedDB-project
Copy and run first the database_creation.sql file
Then run the triggers.sql file
Then run the database_filling.sql
Test the code with the test file by running the procedures and updating the dates